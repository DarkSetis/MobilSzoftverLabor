package com.example.gamelister.network

object NetworkConfig {
    const val API_URL = "https://www.giantbomb.com/api/"
    const val API_KEY = "29ca67532d0ac252145fcd5f497c123d6cd25fb0"
    const val RESPONSE_FORMAT = "json"
}