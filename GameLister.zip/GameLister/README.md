# GameLister
Mobilszoftver laboratórium kurzusra készített játék listázó java alkalmazás kotlinra való átírása.
